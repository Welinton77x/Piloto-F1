import React from "react";
import * as THREE from "three";
import {rad} from "../lib/anim";

export const Mat: React.FC<{
  color: string;
  opacity?: number;
  emissive?: string;
  ei?: number;
  metal?: number;
}> = ({color, opacity = 1, emissive = "#000000", ei = 0, metal = 0}) => (
  <meshStandardMaterial
    color={color}
    flatShading
    transparent={opacity < 1}
    opacity={opacity}
    emissive={emissive}
    emissiveIntensity={ei}
    metalness={metal}
    roughness={0.8}
  />
);

export type DriverProps = {
  outfit?: "racing" | "mechanic" | "training";
  headTilt?: number; // graus, em Z
  lean?: number; // graus, tronco para frente (X)
  helmetScale?: number;
  helmetColor?: string;
  neckScale?: number;
  legMetal?: number; // 0-1
  wave?: number; // graus do braço direito
  coreGlow?: number;
  harness?: number;
  xray?: number; // 0-1 (1 = corpo translúcido)
  scale?: number;
  position?: [number, number, number];
  rotationY?: number;
};

const OUT = {
  racing: {shirt: "#d83a34", pants: "#2b2f3a", head: "#f4f4f4", skin: "#e9b98f"},
  mechanic: {shirt: "#2f6fb5", pants: "#27598f", head: "#2f6fb5", skin: "#e9b98f"},
  training: {shirt: "#2e9e4f", pants: "#2b2f3a", head: "#2e9e4f", skin: "#e9b98f"},
} as const;

/** Personagem original, low-poly, sem nome. 'mechanic' = mascote do canal (calça, camisa e boné azuis). */
export const Driver: React.FC<DriverProps> = ({
  outfit = "racing",
  headTilt = 0,
  lean = 0,
  helmetScale = 1,
  helmetColor,
  neckScale = 1,
  legMetal = 0,
  wave = 0,
  coreGlow = 0,
  harness = -1,
  xray = 0,
  scale = 1,
  position = [0, 0, 0],
  rotationY = 0,
}) => {
  const c = OUT[outfit];
  const op = 1 - xray * 0.65;
  return (
    <group position={position} scale={scale} rotation={[0, rotationY, 0]}>
      {/* pernas */}
      <mesh position={[-0.13, 0.28, 0.1]}>
        <boxGeometry args={[0.16, 0.5, 0.2]} />
        <Mat color={legMetal > 0.5 ? "#aab4c0" : c.pants} metal={legMetal} opacity={op} />
      </mesh>
      <mesh position={[0.13, 0.28, 0.1]}>
        <boxGeometry args={[0.16, 0.5, 0.2]} />
        <Mat color={legMetal > 0.5 ? "#aab4c0" : c.pants} metal={legMetal} opacity={op} />
      </mesh>
      {/* tronco (pivô na cintura) */}
      <group position={[0, 0.55, 0]} rotation={[rad(lean), 0, 0]}>
        <mesh position={[0, 0.22, 0]}>
          <boxGeometry args={[0.46, 0.46, 0.26]} />
          <Mat color={c.shirt} opacity={op} />
        </mesh>
        {/* abdômen */}
        <mesh position={[0, 0.08, 0.14]}>
          <boxGeometry args={[0.3, 0.16, 0.04]} />
          <Mat color="#ffb74d" emissive="#ff9800" ei={coreGlow * 1.4} opacity={coreGlow > 0 ? 1 : 0.0001} />
        </mesh>
        {/* cinto de 5 pontos (x) */}
        {harness >= 0 && (
          <group>
            {[-1, 1].map((s) => (
              <mesh key={s} position={[s * 0.12, 0.26, 0.14]} rotation={[0, 0, s * rad(-12)]}>
                <boxGeometry args={[0.05, 0.5, 0.02]} />
                <Mat color={harness > 0 ? "#ffd400" : "#111111"} emissive="#ffd400" ei={harness * 1.2} />
              </mesh>
            ))}
          </group>
        )}
        {/* braços */}
        <mesh position={[-0.3, 0.2, 0]}>
          <boxGeometry args={[0.12, 0.42, 0.12]} />
          <Mat color={c.shirt} opacity={op} />
        </mesh>
        <group position={[0.3, 0.4, 0]} rotation={[0, 0, rad(-wave)]}>
          <mesh position={[0, -0.2, 0]}>
            <boxGeometry args={[0.12, 0.42, 0.12]} />
            <Mat color={c.shirt} opacity={op} />
          </mesh>
          <mesh position={[0, -0.44, 0]}>
            <icosahedronGeometry args={[0.07, 0]} />
            <Mat color={c.skin} />
          </mesh>
        </group>
        {/* pescoço */}
        <mesh position={[0, 0.5, 0]} scale={[neckScale, 1, neckScale]}>
          <cylinderGeometry args={[0.07, 0.08, 0.14, 6]} />
          <Mat color={c.skin} opacity={op} />
        </mesh>
        {/* cabeça */}
        <group position={[0, 0.72, 0]} rotation={[0, 0, rad(headTilt)]} scale={helmetScale}>
          {outfit === "mechanic" ? (
            <>
              <mesh>
                <icosahedronGeometry args={[0.19, 1]} />
                <Mat color={c.skin} />
              </mesh>
              {/* boné azul */}
              <mesh position={[0, 0.07, 0]}>
                <sphereGeometry args={[0.2, 8, 5, 0, Math.PI * 2, 0, Math.PI / 2]} />
                <Mat color="#2f6fb5" />
              </mesh>
              <mesh position={[0, 0.06, 0.2]}>
                <boxGeometry args={[0.26, 0.025, 0.16]} />
                <Mat color="#245a96" />
              </mesh>
              {/* olhos e sorriso */}
              <mesh position={[-0.07, -0.01, 0.17]}>
                <boxGeometry args={[0.035, 0.05, 0.02]} />
                <Mat color="#1b1b1b" />
              </mesh>
              <mesh position={[0.07, -0.01, 0.17]}>
                <boxGeometry args={[0.035, 0.05, 0.02]} />
                <Mat color="#1b1b1b" />
              </mesh>
              <mesh position={[0, -0.08, 0.17]}>
                <boxGeometry args={[0.1, 0.025, 0.02]} />
                <Mat color="#8a3b2a" />
              </mesh>
            </>
          ) : (
            <>
              <mesh>
                <icosahedronGeometry args={[0.24, 1]} />
                <Mat color={helmetColor ?? c.head} />
              </mesh>
              <mesh position={[0, 0.0, 0.19]}>
                <boxGeometry args={[0.3, 0.1, 0.1]} />
                <Mat color="#12202e" emissive="#4dd0ff" ei={0.35} />
              </mesh>
              <mesh position={[0, 0.17, 0]}>
                <boxGeometry args={[0.05, 0.05, 0.4]} />
                <Mat color="#ffd400" />
              </mesh>
            </>
          )}
        </group>
      </group>
    </group>
  );
};

/** Carro genérico fictício (sem equipes ou patrocinadores). Eixo longo = Z. */
export const Car: React.FC<{opacity?: number; yaw?: number; position?: [number, number, number]}> = ({
  opacity = 1,
  yaw = 0,
  position = [0, 0, 0],
}) => (
  <group position={position} rotation={[0, rad(yaw), 0]}>
    <mesh position={[0, 0.3, 0]}>
      <boxGeometry args={[0.8, 0.28, 3.0]} />
      <Mat color="#d83a34" opacity={opacity} />
    </mesh>
    <mesh position={[0, 0.27, 1.8]}>
      <boxGeometry args={[0.3, 0.16, 1.0]} />
      <Mat color="#d83a34" opacity={opacity} />
    </mesh>
    <mesh position={[0, 0.2, 2.35]}>
      <boxGeometry args={[1.5, 0.05, 0.3]} />
      <Mat color="#222831" opacity={opacity} />
    </mesh>
    <mesh position={[0, 0.8, -1.5]}>
      <boxGeometry args={[1.3, 0.05, 0.35]} />
      <Mat color="#222831" opacity={opacity} />
    </mesh>
    <mesh position={[0, 0.55, -1.5]}>
      <boxGeometry args={[0.06, 0.5, 0.2]} />
      <Mat color="#222831" opacity={opacity} />
    </mesh>
    {[
      [-0.62, 0.3, 1.6],
      [0.62, 0.3, 1.6],
      [-0.62, 0.34, -1.3],
      [0.62, 0.34, -1.3],
    ].map((p, i) => (
      <mesh key={i} position={p as [number, number, number]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.3, 0.3, 0.32, 8]} />
        <Mat color="#1c1f26" opacity={Math.max(opacity, 0.5)} />
      </mesh>
    ))}
    {/* halo */}
    <mesh position={[0, 0.9, 0.2]} rotation={[rad(80), 0, 0]}>
      <torusGeometry args={[0.32, 0.03, 4, 8, Math.PI]} />
      <Mat color="#9aa4b2" opacity={Math.max(opacity, 0.5)} />
    </mesh>
  </group>
);

export const Heart: React.FC<{color: string; pulse: number; position?: [number, number, number]}> = ({
  color,
  pulse,
  position = [0, 0, 0],
}) => (
  <group position={position} scale={pulse}>
    <mesh position={[-0.28, 0.2, 0]}>
      <icosahedronGeometry args={[0.42, 1]} />
      <Mat color={color} emissive={color} ei={0.25} />
    </mesh>
    <mesh position={[0.28, 0.2, 0]}>
      <icosahedronGeometry args={[0.42, 1]} />
      <Mat color={color} emissive={color} ei={0.25} />
    </mesh>
    <mesh position={[0, -0.32, 0]} rotation={[0, 0, Math.PI]}>
      <coneGeometry args={[0.62, 0.9, 6]} />
      <Mat color={color} emissive={color} ei={0.25} />
    </mesh>
  </group>
);

export const Ground: React.FC<{y?: number; color?: string}> = ({y = 0, color = "#3a4252"}) => (
  <mesh position={[0, y - 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
    <planeGeometry args={[60, 60]} />
    <Mat color={color} />
  </mesh>
);

export const Lights: React.FC = () => (
  <>
    <ambientLight intensity={0.85} />
    <directionalLight position={[4, 8, 5]} intensity={1.6} />
    <directionalLight position={[-5, 3, -4]} intensity={0.5} color="#9fc4ff" />
  </>
);

export const tubeFromPoints = (pts: [number, number, number][], radius: number) => {
  const curve = new THREE.CatmullRomCurve3(pts.map((p) => new THREE.Vector3(...p)));
  return new THREE.TubeGeometry(curve, 16, radius, 6, false);
};
