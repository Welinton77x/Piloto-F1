# Por que o piloto de F1 parece só ficar sentado? — projeto Remotion (roteiro v1 aprovado)

Short 1080×1920, 30 fps, 3D low-poly real (`@remotion/three`). Nada aqui foi instalado, renderizado ou ouvido:
o código foi escrito sem rede e só passou por checagem de sintaxe (0 erros) e pelo teste de integridade do plano (11 cenas, 2940 frames).

## Passo a passo (no seu computador, Node 20+, Python 3.10+, ffmpeg)
```bash
npx create-video@latest --yes --blank --no-tailwind piloto-f1 && cd piloto-f1
npx remotion add @remotion/three @remotion/google-fonts       # mesma versão do remotion
npm i three @react-three/fiber @react-three/drei && npm i -D @types/three
# copie por cima do projeto: src/  public/  scripts/  tsconfig.json  remotion.config.ts  (apague o src antigo)
node scripts/make_sfx.mjs                                       # efeitos e trilha (já vêm gerados em public/sfx)
pip install edge-tts && python scripts/tts_edge.py              # voz grátis; OU a ElevenLabs:
# ELEVENLABS_API_KEY=... ELEVENLABS_VOICE_ID=... python scripts/tts_elevenlabs.py   (gasta créditos)
npx tsc --noEmit                                                # corrija eventuais erros de tipo
npx remotion studio                                             # pré-visualização
npx remotion render PilotoF1 out/piloto-f1-raw.mp4 --gl=angle --concurrency=4 --crf=17
ffmpeg -i out/piloto-f1-raw.mp4 -af loudnorm=I=-14:TP=-1.5:LRA=11 -c:v copy -c:a aac out/piloto-f1.mp4
```

## Como funciona
- `src/data/scene-plan.ts` = plano aprovado (v1). `src/data/scenes.ts` só ESTICA uma cena se a voz real não couber
  (fala começa 8 f após o corte, respiro de 18 f); sem `timing.json` usa os frames do plano.
- Legendas (`Overlay.tsx`): blocos de até 17 caracteres; tempos exatos por palavra se o `timing.json` casar com o texto,
  senão distribuição por tamanho da palavra.
- Câmera por cena (`Main.tsx > CamRig`) com as poses do plano + deriva lenta; tremor só na cena 1.
- Personagens: piloto de capacete (genérico) e o mascote do canal (calça, camisa e boné azuis, estilo mecânico/engenheiro) no fecho.

## Limitações conhecidas (honestas)
- Rótulos (FORÇA G, PESCOÇO…) e contadores (kg, bpm) são 2D em posição fixa, não ancorados por projeção ao objeto 3D.
- A balança e o display de kg são 2D sobrepostos; o 3D mostra só a plataforma.
- Wordmark "POR DENTRO LAB" é provisório (texto). Falta o arquivo do logo.
- Posições/escala dos modelos são estimativas sem render: espere ajustes (ângulos de câmera, objetos atravessando).
- Se o `Audio` de `remotion` for descontinuado na sua versão, troque por `Html5Audio` ou `Audio` de `@remotion/media`.
